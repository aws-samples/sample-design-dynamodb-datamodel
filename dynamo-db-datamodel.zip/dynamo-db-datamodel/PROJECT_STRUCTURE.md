# DDB-Datamodel Project Structure

## 📁 Project Files for Repository Upload

### **Core Files:**
1. `README.md` - Project documentation
2. `transaction-system-secure1.yaml` - Production CloudFormation template
3. `DDB_pythoncode_14jul.py` - Lambda function code
4. `Security-Findings-Report.md` - Security analysis report

### **Security Analysis Files:**
5. `security-rules.guard` - CloudFormation Guard rules
6. `cfn-guard-final-findings.txt` - Security scan results
7. `cfn-guard-final-findings.json` - Security scan JSON format

### **Supporting Files:**
8. `lambda_function.py` - Alternative Lambda code
9. `images/ddb-datamodel-diagram.png` - Architecture diagram

## 🚀 **Deployment Instructions:**

### **1. Deploy Infrastructure:**
```bash
aws cloudformation deploy \
  --template-file transaction-system-secure1.yaml \
  --stack-name ddb-datamodel-system \
  --parameter-overrides Environment=dev \
  --capabilities CAPABILITY_IAM
```

### **2. Test Lambda Function:**
```bash
aws lambda invoke \
  --function-name dev-transaction-processor-secure \
  --payload '{"body":"{\"operation\":\"create_transaction\",\"data\":{\"customer_id\":\"12345\",\"transaction_type\":\"PURCHASE\",\"status\":\"PENDING\"}}"}' \
  response.json
```

### **3. Security Validation:**
```bash
cfn-guard validate \
  --data transaction-system-secure1.yaml \
  --rules security-rules.guard
```

## 📊 **Security Compliance:**
- **81% CloudFormation Guard compliance**
- **Enterprise-grade encryption**
- **VPC isolation**
- **IAM least privilege**
- **Comprehensive logging**

## 🏗️ **Architecture:**
- **DynamoDB**: Single-table design with GSI
- **Lambda**: VPC-enabled with X-Ray tracing
- **API Gateway**: IAM-authenticated REST API
- **KMS**: Customer-managed encryption keys
- **CloudWatch**: Encrypted logging with retention

## 📈 **Use Cases:**
- Transaction processing systems
- Event-driven architectures
- Secure data modeling patterns
- Enterprise CloudFormation templates